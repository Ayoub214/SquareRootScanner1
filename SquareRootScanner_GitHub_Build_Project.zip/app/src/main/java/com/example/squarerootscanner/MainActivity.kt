package com.example.squarerootscanner

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {
 private lateinit var previewView: PreviewView
 private lateinit var scanned: TextView
 private lateinit var result: TextView
 private val executor=Executors.newSingleThreadExecutor()
 private val recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

 override fun onCreate(b:Bundle?) { super.onCreate(b); setContentView(R.layout.activity_main)
  previewView=findViewById(R.id.previewView); scanned=findViewById(R.id.scanned); result=findViewById(R.id.result)
  if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) startCamera()
  else ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.CAMERA),10)
 }
 override fun onRequestPermissionsResult(r:Int,p:Array<out String>,g:IntArray){super.onRequestPermissionsResult(r,p,g);if(r==10&&g.isNotEmpty()&&g[0]==PackageManager.PERMISSION_GRANTED)startCamera()}
 private fun startCamera(){
  ProcessCameraProvider.getInstance(this).addListener({
   val provider=ProcessCameraProvider.getInstance(this).get()
   val preview=Preview.Builder().build().also{it.surfaceProvider=previewView.surfaceProvider}
   val analysis=ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
   analysis.setAnalyzer(executor){proxy->
    val mi=proxy.image
    if(mi==null){proxy.close();return@setAnalyzer}
    recognizer.process(InputImage.fromMediaImage(mi,proxy.imageInfo.rotationDegrees))
     .addOnSuccessListener{t->
      val m=Regex("""[-+]?\d+(?:[\.,]\d+)?""").find(t.text)
      val v=m?.value?.replace(",",".")?.toDoubleOrNull()
      if(v!=null)runOnUiThread{
       scanned.text="Scanned number: $v"
       result.text=if(v>=0)"√ $v = ${String.format(Locale.US,"%.6f",sqrt(v)).trimEnd('0').trimEnd('.')}"
       else "Negative number has no real square root"
      }
     }.addOnCompleteListener{proxy.close()}
   }
   provider.unbindAll(); provider.bindToLifecycle(this,CameraSelector.DEFAULT_BACK_CAMERA,preview,analysis)
  },ContextCompat.getMainExecutor(this))
 }
 override fun onDestroy(){recognizer.close();executor.shutdown();super.onDestroy()}
}