# Square Root Scanner

This Android app uses the phone camera and Google ML Kit OCR to read a number and calculate its square root.

Examples:
- 49 -> 7
- 144 -> 12
- 2.25 -> 1.5

## Build without Android Studio

1. Upload/extract these project files into the root of your GitHub repository.
2. Commit to the `main` branch.
3. GitHub Actions will automatically build the debug APK.
4. Open the repository's **Actions** tab.
5. Open the successful **Build Square Root Scanner APK** run.
6. Under **Artifacts**, download `SquareRootScanner-debug-APK`.

The workflow is included at `.github/workflows/build-apk.yml`.
